# Review-only HubSpot mapping

SIMULATED CONTEXT. DO NOT IMPORT. Every row is ineligible for live export.

| Draft | Proposed HubSpot fields | Resolve before any real handoff |
| --- | --- | --- |
| Company | Name, Company domain name | Confirm identity, existing Company Record ID and preserve its owner |
| Note | Note body, Activity date; company association | Reconcile the existing POC note; preserve evidence and simulation labels |
| Task | Task title, Due date, Task type=To-Do, Task status=Not started, Notes, Activity assigned to; company association | Resolve actual task/owner IDs and task existence; retain the existing owner |

Local draft keys and simulation flags are review metadata, not HubSpot properties. Fictional representative IDs never populate actual owner fields. Scheduled task end is the draft due time; an original callback deadline stays separate in JSON. No completed calls, emails, deals, revenue or lifecycle updates are drafted.

Local stable keys make repeated file generation reproducible. They do not make activity imports idempotent. Existing simulated task IDs indicate manual reconciliation/update after actual-ID lookup, not a repeatable activity import. Existing company ownership is never overwritten by an unowned task assignment.

Official documentation checked 2026-10-22 supports the field mapping: [file requirements](https://knowledge.hubspot.com/import-and-export/set-up-your-import-file), [import behaviour](https://knowledge.hubspot.com/import-and-export/understand-the-import-tool), [activity fields](https://knowledge.hubspot.com/properties/hubspots-default-activity-properties). Company identifiers can associate activities; task imports require title and due date. Notes/tasks can be created but not updated by activity import. Portal permissions, mapping and record resolution remain untested. No integration or import is implemented.
